import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';

  inputVariable:string = "This is Parents Data";

  constructor(){

    
  }


getDataFromChild(value){

  console.log(value);

}


}
