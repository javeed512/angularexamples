import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterLink, RouterLinkActive } from '@angular/router';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] ,
  providers:[UserService]
})
export class AppComponent {
  title = 'myapp';

    

      constructor(private router:Router , private user:UserService){  

       this.get();
      }


      

    displayHome(){

      alert('wait your navigating to home page by component')
        this.router.navigate(['/home']);
        


    }


      get(){

          this.user.getUserData();


      }




}
