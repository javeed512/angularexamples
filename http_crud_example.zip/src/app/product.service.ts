import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  url:string = "assets/products.json"

  constructor(private  _http:HttpClient) { }   // predefined service from angular httpclient service


    getAllProducts():Observable<Product[]>{  // get service in productservice class


       return this._http.get<Product[]>(this.url);


    }


}



interface Product{

  pid:number;
  pname:string;
  price:number;


}