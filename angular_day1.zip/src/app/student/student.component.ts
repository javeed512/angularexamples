import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

    sid:number = 102;
    studentName:string = 'sai baba';



  constructor() { }

  ngOnInit(): void {
  }

}
