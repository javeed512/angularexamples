import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';

  id:number = 101;
  uname:string = 'JAVEED';

  url:string = "assets/yellow.jpg";

  color1:string = "orange";


   get(){

      alert('Save button click event occur');


    }



}
