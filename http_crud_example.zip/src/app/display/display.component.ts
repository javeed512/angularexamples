import { Component, OnInit } from '@angular/core';

import { ProductService } from '../product.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

    productList:Product[] = [];

    product:Product;

  constructor(private _service:ProductService) { }

  ngOnInit(): void {

      this.getAllProducts();

  }


  getAllProducts(){

      this._service.getAllProducts().subscribe(data => 
                                                this.productList = data
                                              ); 


  }


  delete(i){

    console.log('deleted '+i)
    this.productList.splice(i,1);

   

  }


  addProduct(data){

    this.productList.push(data);




  }





}



interface Product{

  pid:number;
  pname:string;
  price:number;


}