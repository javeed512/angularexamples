import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  registerForm:FormGroup;

  submitted = false;

  constructor(private  formBuilder:FormBuilder) { }

  ngOnInit(): void {

    this.registerForm =      this.formBuilder.group({

        firstName:['',Validators.required],
        lastName:['',[Validators.required,Validators.minLength(6)]],
        email:['',[Validators.required,Validators.email]],
        password:['',[Validators.required,Validators.minLength(6)]]
    });
  }


  get f(){  // for easy access to form fields and controls

    return this.registerForm.controls;

}


register(){

    this.submitted = true;

    if(this.registerForm.invalid){
      return;

    }

    alert('REGISTRATION SUCCESSFULL');
}



    






}
