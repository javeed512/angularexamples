import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  id:string;

  constructor(private route:ActivatedRoute) { }

  ngOnInit(): void {

      this.route.params.subscribe(param => { this.id = param['sid'] })

        alert('Feedback for Student with id '+this.id)

  }

}
